<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">

				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				<li><a href="change-password.php"><i class="fa fa-user"></i>Change Password</a></li>
				
					
					<li><a href="#"><i class="fa fa-desktop"></i> Rooms</a>
					<ul>
						<li><a href="create-room.php">Add a Room</a></li>
						<li><a href="manage-rooms.php">Manage Rooms</a></li>
					</ul>
				</li>
				<li><a href="#"><i class="fa fa-desktop"></i> Dues</a>
					<ul>
						<li><a href="add-dues.php">Add Dues</a></li>
						<li><a href="manage-dues.php">Manage Dues</a></li>
					</ul>
				</li>
				<li><a href="#"><i class="fa fa-desktop"></i> Transactions</a>
					<ul>
						<li><a href="transcation.php">Add Transaction</a></li>
						<li><a href="manage-tx.php">Manage Transactions</a></li>
					</ul>
				</li>
				
				<li><a href="#"><i class="fa fa-desktop"></i> Notice Board</a>
					<ul>
						<li><a href="notice.php">Add Notice</a></li>
						<li><a href="manage-notice.php">Manage Notice</a></li>
					</ul>
				<li><a href="registration.php"><i class="fa fa-user"></i>Hostel Booking</a></li>
				<li><a href="manage-students.php"><i class="fa fa-users"></i>Students Details</a></li>
				<li><a href="complaints.php"><i class="fa fa-user"></i>Complaints</a></li>
				<li><a href="#"><i class="fa fa-desktop"></i> Certificates</a>
					<ul>
						<li><a href="no-dues.php">No Dues</a></li>
						<li><a href="leave.php">Leave Application</a></li>
						<li><a href="bonafide.php">Hostel Bonafide</a></li>
						
					</ul>
				</li>
				
			


			
		</nav>