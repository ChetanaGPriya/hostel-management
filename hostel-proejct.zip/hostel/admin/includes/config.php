<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="hostel8";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>