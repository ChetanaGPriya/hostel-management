<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="bookh";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>